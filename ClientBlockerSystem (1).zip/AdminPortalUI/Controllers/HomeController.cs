using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

public class HomeController : Controller
{
    private readonly string _connectionString = "your_connection_string";

    public IActionResult Index()
    {
        var clients = new List<string>();
        using var conn = new SqlConnection(_connectionString);
        conn.Open();
        var cmd = new SqlCommand("SELECT SystemName FROM Clients", conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            clients.Add(reader.GetString(0));
        }
        return View(clients);
    }

    public IActionResult Apps(string systemName)
    {
        var apps = new List<string>();
        using var conn = new SqlConnection(_connectionString);
        conn.Open();
        var cmd = new SqlCommand("SELECT AppName FROM BlockedApplications WHERE ClientId = (SELECT Id FROM Clients WHERE SystemName = @SystemName)", conn);
        cmd.Parameters.AddWithValue("@SystemName", systemName);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            apps.Add(reader.GetString(0));
        }
        ViewBag.SystemName = systemName;
        return View(apps);
    }

    public IActionResult Websites(string systemName)
    {
        var urls = new List<string>();
        using var conn = new SqlConnection(_connectionString);
        conn.Open();
        var cmd = new SqlCommand("SELECT Url FROM BlockedWebsites WHERE ClientId = (SELECT Id FROM Clients WHERE SystemName = @SystemName)", conn);
        cmd.Parameters.AddWithValue("@SystemName", systemName);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            urls.Add(reader.GetString(0));
        }
        ViewBag.SystemName = systemName;
        return View(urls);
    }
}