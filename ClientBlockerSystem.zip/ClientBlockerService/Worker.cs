using System.Diagnostics;
using System.Net.Http.Json;
using System.Configuration;
using Microsoft.Extensions.Hosting;

public class Worker : BackgroundService
{
    private readonly HttpClient _httpClient = new();
    private readonly string _apiBaseUrl = "https://yourserver.com/api";
    private readonly string _systemName = Environment.MachineName;
    private readonly string _connectionString = "your_connection_string";

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await SendHeartbeat();

            var apps = GetBlockedApplications();
            var sites = GetBlockedWebsites();

            BlockApplications(apps);
            BlockWebsites(sites);

            await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
        }
    }

    private async Task SendHeartbeat()
    {
        await _httpClient.PostAsJsonAsync($"{_apiBaseUrl}/client/heartbeat", new { SystemName = _systemName });
    }

    private List<string> GetBlockedApplications()
    {
        var list = new List<string>();
        // ADO.NET code goes here
        return list;
    }

    private List<string> GetBlockedWebsites()
    {
        var list = new List<string>();
        // ADO.NET code goes here
        return list;
    }

    private void BlockApplications(List<string> appNames)
    {
        foreach (var proc in Process.GetProcesses())
        {
            if (appNames.Any(app => proc.ProcessName.Contains(app, StringComparison.OrdinalIgnoreCase)))
            {
                try { proc.Kill(); } catch { }
            }
        }
    }

    private void BlockWebsites(List<string> urls)
    {
        string hostFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"drivers\etc\hosts");
        var lines = File.ReadAllLines(hostFile).Where(line => !urls.Any(u => line.Contains(u))).ToList();

        foreach (var url in urls)
        {
            lines.Add($"127.0.0.1 {url}");
        }

        File.WriteAllLines(hostFile, lines);
    }
}