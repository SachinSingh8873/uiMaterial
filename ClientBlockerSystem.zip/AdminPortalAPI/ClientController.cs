using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

[ApiController]
[Route("api/[controller]")]
public class ClientController : ControllerBase
{
    private readonly string _connectionString = "your_connection_string";

    [HttpPost("heartbeat")]
    public IActionResult Heartbeat([FromBody] ClientHeartbeatDto dto)
    {
        using var conn = new SqlConnection(_connectionString);
        conn.Open();
        var cmd = new SqlCommand("IF EXISTS (SELECT 1 FROM Clients WHERE SystemName = @SystemName) " +
            "UPDATE Clients SET LastSeen = GETUTCDATE() WHERE SystemName = @SystemName " +
            "ELSE INSERT INTO Clients (SystemName, LastSeen) VALUES (@SystemName, GETUTCDATE())", conn);
        cmd.Parameters.AddWithValue("@SystemName", dto.SystemName);
        cmd.ExecuteNonQuery();
        return Ok();
    }

    [HttpGet("blockedapps")]
    public IActionResult GetBlockedApps(string systemName)
    {
        var apps = new List<string>();
        using var conn = new SqlConnection(_connectionString);
        conn.Open();
        var cmd = new SqlCommand("SELECT AppName FROM BlockedApplications WHERE ClientId = " +
            "(SELECT Id FROM Clients WHERE SystemName = @SystemName) AND IsBlocked = 1", conn);
        cmd.Parameters.AddWithValue("@SystemName", systemName);
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) apps.Add(reader.GetString(0));
        return Ok(apps);
    }

    [HttpGet("blockedwebsites")]
    public IActionResult GetBlockedWebsites(string systemName)
    {
        var urls = new List<string>();
        using var conn = new SqlConnection(_connectionString);
        conn.Open();
        var cmd = new SqlCommand("SELECT Url FROM BlockedWebsites WHERE ClientId = " +
            "(SELECT Id FROM Clients WHERE SystemName = @SystemName) AND IsBlocked = 1", conn);
        cmd.Parameters.AddWithValue("@SystemName", systemName);
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) urls.Add(reader.GetString(0));
        return Ok(urls);
    }
}

public class ClientHeartbeatDto
{
    public string SystemName { get; set; }
}